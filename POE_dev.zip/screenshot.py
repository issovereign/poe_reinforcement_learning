import cv2
import numpy as np

vid = cv2.VideoCapture('poe_test.mkv')
if not vid.isOpened():
    print("Nop")

count = 0
while True:
    ret, frame = vid.read()
    if not ret:
        print("Cannot receive frame")
        break
    # filt = np.argwhere(frame != [0, 0, 0])
    height, width = 783, 1377
    final = np.zeros((height, width, 3), dtype=int)
    final = frame[0:height+1, 0:width+1, :]

    final = cv2.resize(final, (1920, 1080), interpolation=cv2.INTER_LINEAR)
    # cv2.imshow('123',  final)
    cv2.imwrite(f'./mydata/{count}.jpg', final)
    count += 1
    # cv2.imshow('123',  frame)
    if cv2.waitKey(1) == ord('p'):
        break

vid.release()
cv2.destroyAllWindows()