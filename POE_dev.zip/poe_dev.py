from itertools import dropwhile
import cv2
import darknet
import time
import pyautogui as gui
import keyboard as key
import random
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from queue import PriorityQueue
import os
import glob


win_title = 'YOLOv4 POE DETECTOR'

cfg_file = 'yolov4_poe/YOLOv4_POE.cfg'
data_file = 'yolov4_poe/obj.data'
weight_file = './yolov4_poe/YOLOv4_POE_best.weights'

drop_cfg_file = 'yolov4_poe_drop/YOLOv4_POE.cfg'
drop_data_file = 'yolov4_poe_drop/obj.data'
drop_weight_file = './yolov4_poe_drop/YOLOv4_POE_drop.weights'

thre = 0.35
show_coordinates = True
px = 954.
py = 434.

move = False
click = False
mx=10.
my=20.
dx=10.
dy=20.
CNNx=10.
CNNy=20.
mons=0
drop_x=0
drop_y=0
drop_id=0
drop=0

BATCH_SIZE = 125
GAMMA = 0.999
TARGET_UPDATE = 10

from collections import namedtuple

Transition = namedtuple('Transition',
                        ('state', 'action', 'reward', 'next_state'))


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class ReplayBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.memory = []
        self.position = 0

    def push(self, state, action, reward, next_state):
        if len(self.memory) < self.capacity:
            self.memory.append(None)
        self.memory[self.position] = (state, action, reward, next_state)
        self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size):
        return random.sample(self.memory, batch_size)

    def __len__(self):
        return len(self.memory)




def load_mons_model():
    # Load Network
    network, class_names, class_colors = darknet.load_network(
            cfg_file,
            data_file,
            weight_file,
            batch_size=1
        )
    # Get Nets Input dimentions
    #width = darknet.network_width(network)
    #height = darknet.network_height(network)
    return network, class_names,class_colors

def load_drop_model():
    # Load Network
    drop_network, drop_class_names, drop_class_colors = darknet.load_network(
            drop_cfg_file,
            drop_data_file,
            drop_weight_file,
            batch_size=1
        )
    # Get Nets Input dimentions
    #width = darknet.network_width(network)
    #height = darknet.network_height(network)
    return drop_network, drop_class_names,drop_class_colors

def mons_detect(mx,my,see_mons):
    global mons
    monster_positions=[]
    darknet_image = darknet.make_image(1920, 1080, 3)
    darknet.copy_image_from_bytes(darknet_image, imgr.tobytes())
    mons_detections = darknet.detect_image(network, class_names, darknet_image, thresh=thre)
    darknet.print_detections(mons_detections, px, py, show_coordinates)
    # print(px,py,dx,dy)
    # mx,my,see_mons = darknet.getX(mons_detections,px,py,mx,my,see_mons)  
    mq, see_mons = darknet.getX(mons_detections,px,py,mx,my,see_mons)  
    while not mq.empty():
        monster_positions.append(mq.get()[-1])
    print('mons:\n', monster_positions)
    darknet.free_image(darknet_image)
    return mons_detections,see_mons,monster_positions
  
    

def drop_detect(dx,dy,see_drop):
    global drop_x,drop_y
    global drop_id,drop
    drop_positions = []
    darknet_image = darknet.make_image(1920, 1080, 3)
    darknet.copy_image_from_bytes(darknet_image, imgr.tobytes())
    drop_detections = darknet.detect_image(drop_network, drop_class_names, darknet_image, thresh=thre)
    darknet.drop_print_detections(drop_detections, show_coordinates)
    print(drop_detections)
   
    # dx,dy,see_drop = darknet.getdrop(drop_detections,px,py,dx,dy,see_drop)
    dq, see_drop = darknet.getdrop(drop_detections,px,py,dx,dy,see_drop)
    while not dq.empty():
        drop_positions.append(dq.get()[-1])

    print('drop:\n', drop_positions) 
    darknet.free_image(darknet_image)
    return drop_detections,see_drop,drop_positions

def draw_box(detections,class_colors):
    
    imgd = darknet.draw_boxes(detections, imgr, class_colors)
    
    return imgd

def setXY(see_drop,see_mons,imgr,CNNx,CNNy):
    if not see_drop:
        if not see_mons:
            a = CNNRF.predict(imgr)
            print(a)
            if a == 0 or a == 3:
                CNNx = random.randint(430,543)
                CNNy = random.randint(135,210)
            elif a == 1 or a == 2 or a == 4:
                CNNx = 224
                CNNy = 926
            elif a == 5:
                CNNx = 280
                CNNy = random.randint(300,530)
            elif a == 6 or a == 7:
                CNNx = 1400
                CNNy = 86
    return CNNx,CNNy

def act_move(imgd, action, mons_detections, drop_detections, CNNx, CNNy, click):
    if move:
        if action == 0: # move to monsters
            closest = [CNNx, CNNy]
            min_dist = float('inf')
            for m_pos in mons_detections:
                if m_pos == []:
                    cur_dist = float('inf')
                else:
                    cur_dist = pow(abs(m_pos[0] - px), 2) + pow(abs(m_pos[1] - py), 2)

                if cur_dist < min_dist:
                    min_dist = cur_dist
                    closest = m_pos

            print("Monsgui:", closest[0],',', closest[1])
            # cv2.circle(imgd, (int(closest[0]), int(closest[1])), 10, (0, 255, 0), -1)
            gui.moveTo(closest[0], closest[1])
            print('move')

            if not click:
                gui.mouseDown(button='right')
                click = True

        elif action == 1: # move to drops
            closest = [CNNx, CNNy]
            min_dist = float('inf')
            for d_pos in drop_detections:
                if d_pos == []:
                    cur_dist = float('inf')
                else:
                    cur_dist = pow(abs(d_pos[0] - px), 2) + pow(abs(d_pos[1] - py), 2)

                if cur_dist < min_dist:
                    min_dist = cur_dist
                    closest = d_pos
                
            print("Dropsgui:", closest[0],',', closest[1])
            # cv2.circle(imgd, (int(closest[0]), int(closest[1])), 10, (255, 255, 0), -1)
            gui.moveTo(closest[0], closest[1])
            print('move')

            gui.mouseUp(button='right')
            gui.click()
            click = False





def basic_move(move, click, CNNx, CNNy):
    if move:
        gui.moveTo(CNNx,CNNy)
        print('move')

        gui.mouseUp(button='right')
        gui.click()
        click = False


# 定义你的DQN模型
class DQN(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(DQN, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, output_dim)
        )

    def forward(self, x):
        return self.fc(x)


def create_state(monster_positions, drop_positions):
    # 创建一个状态向量，包含所有怪物和掉落物的位置
    state = np.zeros((MAX_MONSTERS + MAX_DROPS) * 2)
    for i, pos in enumerate(monster_positions):
        state[i * 2: i * 2 + 2] = pos
    for i, pos in enumerate(drop_positions):
        state[(i + MAX_MONSTERS) * 2: (i + MAX_MONSTERS) * 2 + 2] = pos
    return state

def choose_action(state):
    # 使用DQN模型选择一个动作
    state_tensor = torch.tensor(state, dtype=torch.float32).to(device=device).unsqueeze(0)
    with torch.no_grad():
        action_values = policy_net(state_tensor)
    print("action_values:", action_values)
    action = torch.argmax(action_values).item()
    return action

def compute_reward(action, monster_positions, drop_positions):
    # 计算奖励，假设奖励与怪物/掉落物的数量和你的角色与他们的距离成反比
    if action == 0:  # 如果选择靠近怪物
        num_monsters = len(monster_positions)
        distance = np.mean([np.linalg.norm(pos) for pos in monster_positions]) if num_monsters > 0 else 1
        reward = num_monsters / distance
    else:  # 如果选择靠近掉落物
        num_drops = len(drop_positions)
        distance = np.mean([np.linalg.norm(pos) for pos in drop_positions]) if num_drops > 0 else 1
        reward = num_drops / distance
    return reward

def optimize_model():
    if len(memory) < BATCH_SIZE:
        return
    transitions = memory.sample(BATCH_SIZE)
    batch = Transition(*zip(*transitions))
    # print("state:", batch.state)
    # print("action:", torch.tensor(batch.action))
    # print("reward:", torch.tensor(batch.reward))
    # print("next_state:", torch.tensor(batch.next_state))
    # print(batch.state)

    non_final_mask = torch.tensor(tuple(map(lambda s: s is not None,
                                          batch.next_state)), device=device, dtype=torch.bool)
    # non_final_next_states = torch.cat([torch.tensor(s) for s in batch.next_state
    #                                             if s is not None]).to(device=device)
    non_final_next_states = torch.tensor(batch.next_state, dtype=torch.float).to(device=device)
    
    # state_batch = torch.cat(tuple(torch.tensor(s, device=device, dtype=torch.float) for s in batch.state)).unsqueeze(0)
    state_batch = torch.tensor(batch.state, dtype=torch.float).to(device=device)
    action_batch = torch.tensor(batch.action, device=device, dtype=torch.int64).unsqueeze(1)
    reward_batch = torch.tensor(batch.reward, device=device, dtype=torch.float).unsqueeze(1)

    # print("state_batch:", state_batch, state_batch.shape)
    # print("action_batch:", action_batch, action_batch.shape)
    # print(torch.swapaxes(action_batch, 0, 1))
    # print("reward_batch:", reward_batch, reward_batch.shape)
    # print("non_final_mask:", non_final_mask, non_final_mask.shape)
    # print("non_final_next_states:", non_final_next_states, non_final_next_states.shape)

    # print(policy_net(state_batch), policy_net(state_batch).shape)
    state_action_values = policy_net(state_batch).gather(0, action_batch)

    next_state_values = torch.zeros(BATCH_SIZE, device=device)
    # print()

    next_state_values[non_final_mask] = target_net(non_final_next_states).max(1)[0].detach()
    
    expected_state_action_values = (next_state_values * GAMMA) + reward_batch

    loss = F.smooth_l1_loss(state_action_values, expected_state_action_values.unsqueeze(1))
    print("Loss:", loss)

    optimizer.zero_grad()
    loss.backward()
    # for param in policy_net.parameters():
    #     param.grad.data.clamp_(-1, 1)
    torch.nn.utils.clip_grad_value_(policy_net.parameters(), 100)
    optimizer.step()

network, class_names,class_colors = load_mons_model()
drop_network, drop_class_names,drop_class_colors = load_drop_model()



PRETRAINED_MODEL_PATH = 'path_to_your_pretrained_model.pt'
SAVE_MODEL_PATH = 'path_to_save_your_model.pt'
USE_PRETRAINED = False  # Set this to False if you want to train from scratch

MAX_MONSTERS = 5
MAX_DROPS = 5


# 初始化状态和记忆
state = np.zeros((MAX_MONSTERS + MAX_DROPS) * 2)
memory = ReplayBuffer(10000)

TARGET_UPDATE = 10
i_episode = 0

policy_net = DQN((MAX_MONSTERS + MAX_DROPS) * 2 , 2).to(device)
target_net = DQN((MAX_MONSTERS + MAX_DROPS) * 2 , 2).to(device)
target_net.load_state_dict(policy_net.state_dict())
target_net.eval()  # 設置為評估模式，因為我們不會用它來進行訓練

# if USE_PRETRAINED:
#     policy_net.load_state_dict(torch.load(PRETRAINED_MODEL_PATH))

optimizer = torch.optim.RMSprop(policy_net.parameters())

count = 0
imgpath = sorted(glob.glob('./mydata/*.jpg'), key=lambda name:int(name[9:-4]))
for file in imgpath:
# while True:
    see_mons = False
    see_drop = False
    t_prev = time.time()

    # gui.screenshot('b.jpg')
    imgr = cv2.imread(file)
    fps = int(1/(time.time()-t_prev))

    # 同时进行怪物和掉落物的检测
    mons_detections, see_mons, monster_positions = mons_detect(mx, my, see_mons)
    drop_detections, see_drop, drop_positions = drop_detect(dx, dy, see_drop)
    
    # 都沒東西就往左上角走
    if not see_mons and not see_drop:
        basic_move(move, click, CNNx, CNNy)
        if count > 200:
            cv2.putText(imgr, f'FPS {fps}', (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
            cv2.imwrite(f'./output/{count}_n.jpg', imgr)
        count += 1
        continue

    # 根据检测结果绘制边框
    imgd = draw_box(mons_detections, class_colors)
    imgd = draw_box(drop_detections, drop_class_colors)


    # cv2.imshow('', imgd)
    # cv2.waitKey()
    # cv2.destroyAllWindows()

    # 假資料
    # if count % 3 == 0:
    # # 根据检测到的怪物和掉落物的位置，构建状态
    #     monster_positions = [[900, 480], [910, 470], [920, 460]]
    #     drop_positions = [[416, 163], [417, 163], [418, 163]]

    # if count % 3 == 1:
    #     monster_positions = [[890, 480], [900, 470], [910, 460]]
    #     drop_positions = [[416, 163], [417, 163], [418, 163]]

    # if count % 3 == 2:
    #     monster_positions = [[880, 480], [890, 470], [900, 460]]
    #     drop_positions = [[416, 163], [417, 163], [418, 163]]

    print(monster_positions, drop_positions)
    new_state = create_state(monster_positions, drop_positions)

    # 选择一个动作
    action = choose_action(new_state)

    # 根据选择的动作，怪物和掉落物的状态，计算奖励
    reward = compute_reward(action, monster_positions, drop_positions)


    # 将新的经验存储到记忆中
    memory.push(state, action, reward, new_state)

    # 更新状态
    state = new_state

    # 优化模型
    optimize_model()
    target_net_state_dict = target_net.state_dict()
    policy_net_state_dict = policy_net.state_dict()

    # torch.save(policy.state_dict(), SAVE_MODEL_PATH)



    # 每隔TARGET_UPDATE個迴圈，就將target_net的權重更新為policy_net的權重
    if i_episode % TARGET_UPDATE == 0:
        target_net.load_state_dict(policy_net.state_dict())

    i_episode += 1

    if key.is_pressed("/"):
        cv2.imwrite("test.png", imgd)
    
    if count > 200:
        move = True
        act_move(imgd, action, monster_positions, drop_positions, CNNx, CNNy, click)
        
        imgd = cv2.resize(imgd, (1920, 1080), interpolation=cv2.INTER_LINEAR)
        # cv2.rectangle(imgd, (5, 5), (75, 25), (0, 0, 0), -1)
        cv2.putText(imgd, f'FPS {fps}', (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
        cv2.imwrite(f'./output/{count}.jpg', imgd)
        # cv2.imshow(file, imgd)
        # cv2.waitKey()
        # cv2.destroyAllWindows()
    # act_move(action, click, see_drop, see_mons, mx, my, dx, dy, CNNx, CNNy)

    print("count:", count, " action:", action)
    count += 1
    if key.is_pressed("q"):
        break

    if key.is_pressed('w'):
        move = True

    if key.is_pressed("e"):
        move = False
        click = False
        gui.mouseUp(button='right') 

    if cv2.waitKey(1) == ord('q'):
        break

cv2.destroyAllWindows()
